#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#define SCP_MAX_SIZE 4095     //小数据块的大小，超过则为大块内存
//用于指针对齐, a为sizeof(void *)
#define scp_align_ptr(p, a)\
(char *) ((p) + (a-1)) & ~(a-1))

//大数据块
struct scp_big_t
{
	scp_big_t *next; //下一个scp_big_t
	void      *buf;  //缓冲区指针
};

//小数据块
struct scp_data_t
{
	char         *last; //当前内存池内未使用的区域首地址
	char         *end;  //当前内存池内的尾指针
	scp_t        *next; //下一个内存池指针
    unsigned int  failed; //失败次数,超过4则current需要后移
};

//内存池
struct scp_t
{
	scp_data_t  dt;  //内存池的数据块
	size_t      max; //数据块最大值
	scp_data_t *current; //内存池链表的最近使用的内存池指针
	scp_big_t  *large;   //内存池的大数据块链表的头指针
};

//创建一个内存池，size是内存池大小
scp_t* scp_create(size_t  size);
//销毁内存池，释放两个链表
void scp_destroy(scp_t* s);
//在内存池中分配一个内存，大小为size字节
void* scp_alloc(scp_t* pool, size_t size);
//分配一个小数据块
static void* scp_small_alloc(scp_t* pool, size_t size);
//分配一个大数据快
static void* scp_big_alloc(scp_big_t* large, size_t size);
static void* scp_block_alloc(scp_t* pool, size_t size);
//释放大块内存
static int scp_pfree(scp_t *pool, void *p);

struct scp_info_t
{
	char   name[32];
	int    age;
	char   origin[16]；
	char   buf[1];   //变长数据的指针
};

scp_t* scp_create(size_t size)
{
	//使用malloc分配
}

void scp_destroy(scp_t* s)
{
	//使用free释放所有malloc分配的空间
}

void* scp_alloc(scp_t* pool, size_t size)
{
	if (size <= pool->max)
	{
		return scp_small_alloc(pool, size);
	}
	else
	{
		return scp_big_alloc(pool->large, size);
	}
}

//分配小块内存，如果没有，则调用scp_block_alloc分配
void* scp_small_alloc(scp_t* pool, size_t size)
{
	//查找或分配小数据块，返回指针
}
//分配一个数据块，并加入到链表
static void* scp_block_alloc(scp_t* pool, size_t size)
{

}
//分配一个大块内存，并加入链表
void* scp_big_alloc(scp_big_t* large, size_t size)
{
}

//释放大块内存
static int scp_pfree(scp_t *pool, void *p)
{
}

int main(int argc, char *argv[])
{
	//编码使用内存池操作函数分配内存给scp_info_t类型的变量，大小分别为1k和2m
	//释放分配的内存。
	exit(0);
}
