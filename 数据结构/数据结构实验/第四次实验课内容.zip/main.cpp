#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "scp_htindex.h"


int main(int argc, char *argv[])
{
	int  	  		 rtn;
	uint32_t  		 ordersn1 = 64*8192;
	uint32_t  		 ordersn2 = 876;
	scp_stk_order_t *order;
	
	rtn = scp_create_bpus(SCP_BPU_NUM);
	if (rtn)
	{
		printf("scp_create_bpus failed.\n");
		exit(0);
	}

	order = scp_get_by_ordersn(ordersn1);
	if (order)
	{
		if (ordersn1 == order->ordersn)
		{
			printf("match success, ordersn=%d, stockcode=%d.\n", order->ordersn, order->stockcode);
		}
		else
		{
			printf("does not match, find ordersn=%d, getting ordersn=%d\n", ordersn1, order->ordersn);
		}
	}
	else
	{
		printf("ordersn=%d not finded.\n", ordersn1);
	}
		
	order = scp_get_by_ordersn(ordersn2);
	if (order)
	{
		if (ordersn2 == order->ordersn)
		{
			printf("match success, ordersn=%d, stockcode=%d.\n", order->ordersn, order->stockcode);
		}
		else
		{
			printf("does not match, find ordersn=%d, getting ordersn=%d\n", ordersn2, order->ordersn);
		}
	}
	else
	{
		printf("ordersn=%d not finded.\n", ordersn2);
	}

	printf("program exit.\n");

	exit(0);
	
}