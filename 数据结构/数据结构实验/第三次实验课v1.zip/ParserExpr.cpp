// ParserExpr.cpp : Defines the entry point for the DLL application.
//


#include <stdio.h>
#include <set>
#include "ParserExpr.h"

set<char> CParserExpr::m_setOperators;

CParserExpr::CParserExpr()
{
	InitOperator();
}

CParserExpr::~CParserExpr()
{
	m_Map.clear();

	while(!m_Operators.empty())
	{
		m_Operators.pop();
	}

	while(!m_pOperands.empty())
	{
		m_pOperands.pop();
	}
}

void CParserExpr::InitOperator()
{
	Sentinel.strOperator = "#";
	Sentinel.nType = 1;
	Sentinel.nPrecedence = 0;
	Sentinel.nOperandsCount = 0;
	Sentinel.nAssociativity = 0;
	Sentinel.bUnary = false;
	Sentinel.fpEvaluate = NULL;
	/*
	Assign.strOperator = "=";
	Assign.nType = 0;
	Assign.nPrecedence = 3;
	Assign.nOperandsCount = 2;
	Assign.nAssociativity = 0;
	Assign.bUnary = false;
	Assign.fpEvaluate = EvaluateAssignExpr;
	*/
	
	
	
	Add.strOperator = "+";
	Add.nType = 0;
	Add.nPrecedence = 8;
	Add.nOperandsCount = 2;
	Add.nAssociativity = 0;
	Add.bUnary = false;
	Add.fpEvaluate = &CParserExpr::EvaluateAddExpr;
	
	Subtract.strOperator = "-";
	Subtract.nType = 0;
	Subtract.nPrecedence = 8;
	Subtract.nOperandsCount = 2;
	Subtract.nAssociativity = 0;
	Subtract.bUnary = false;
	Subtract.fpEvaluate = &CParserExpr::EvaluateSubtractExpr;
	
	Multiply.strOperator = "*";
	Multiply.nType = 0;
	Multiply.nPrecedence = 16;
	Multiply.nOperandsCount = 2;
	Multiply.nAssociativity = 0;
	Multiply.bUnary = false;
	Multiply.fpEvaluate = &CParserExpr::EvaluateMultiplyExpr;
	
	Divide.strOperator = "/";
	Divide.nType = 0;
	Divide.nPrecedence = 16;
	Divide.nOperandsCount = 2;
	Divide.nAssociativity = 0;
	Divide.bUnary = false;
	Divide.fpEvaluate = &CParserExpr::EvaluateDivideExpr;
	
	
	PRight.strOperator = "#";
	PRight.nType = 0;
	PRight.nPrecedence = 64;
	PRight.nOperandsCount = 0;
	PRight.nAssociativity = 0;
	PRight.bUnary = false;
	
	PLeft.strOperator = "#";
	PLeft.nType = 0;
	PLeft.nPrecedence = 64;
	PLeft.nOperandsCount = 0;
	PLeft.nAssociativity = 0;
	PLeft.bUnary = false;
}


int CParserExpr::EvaluateAddExpr()
{
	//编码实现	
	return 0;
}

int CParserExpr::EvaluateSubtractExpr()
{
	//编码实现	
	
	return 0;
}

int CParserExpr::EvaluateMultiplyExpr()
{
	//编码实现	
	
	return 0;
}

int CParserExpr::EvaluateDivideExpr()
{
	//编码实现	
	
	return 0;
}


int CParserExpr::EvaluateStrcmp()
{
	if (m_pOperands.size() < 2)
	{
		return -1;
	}

	tagOperand stOperand, stOperand1, stOperand2;
	char       szTmp[256];
	
	stOperand1 = m_pOperands.top();
	m_pOperands.pop();

	stOperand2 = m_pOperands.top();
	m_pOperands.pop();

	stOperand.nType = DATATYPE_INT;
	sprintf(szTmp, "%d", strcmp(stOperand2.strValue.c_str(), stOperand1.strValue.c_str()));
	stOperand.strValue = szTmp;
	m_pOperands.push(stOperand);

	return 0;
}

//成功返回0,否则失败
int CParserExpr::ParseExpr(string &expr, char *strResult)
{
	//test
// 	char szLog[8192] = {0};
// 	sprintf(szLog, "Before parse expression: %.800s", expr.data());
// 	WriteLog(szLog);

	int iRetVal;

	m_strExpression = expr;
	m_pszExp = (char*)m_strExpression.data();

	while(!m_pOperands.empty())
	{
		m_pOperands.pop();
	}
	while(!m_Operators.empty())
	{
		m_Operators.pop();
	}

	iRetVal = DoParseExpr();
	if (iRetVal != 0)
	{
		return -1;
	}

	if (m_pOperands.empty())
	{
		strcpy(strResult, "0");
	} 
	else
	{
		strncpy(strResult, m_pOperands.top().strValue.data(), RESULT_MAX_LEN-1);
	}

	return m_pOperands.size();
}

/* 解析表达式，计算表达式的值 */
int CParserExpr::DoParseExpr()
{
	//编码实现	提示如下
	//当m_pszExp为'('或者函数的‘(’则需要递归调用DoParseExpr
	//当m_pszExp为'\t' 或者' '或者'\n'或者','则不处理
	//当m_pszExp为'\0'或者')'时调用Evaluates函数处理
	/*
	代码如下：
	while(1)
	{
		//operator
		switch (*m_pszExp)
		{
		case ' ':   //ignore
		case '\t':  //ignore
		case '\n':  //ignore
		case ',':   //next argument of param
			break;

		case '(':
		    ...
			break;
		case '+':
			...
			break;

			.........
		}
		m_pszExp++;
	}
	*/
	return 0;
}

int CParserExpr::PushOperator(tagOperator &refOperator)
{
	//编码实现	
	return 0;
}

int CParserExpr::Evaluates(tagOperator &refOperator)
{
	//编码实现	
	return 0;
}

/*读取表达式中的操作数*/
const char* CParserExpr::GetSymbolExpr(string &strToken)
{
	char *pszCurChar = m_pszExp;
	char ch = *pszCurChar;
	string::size_type pos;
	
	strToken.erase();
// 	while((ch >='A' && ch <='Z')|| (ch >='a' && ch <='z') || (ch >='0' && ch <='9')
// 		|| ch == '@' || ch =='_' || ch =='.' || ch =='?')
	while(ch != '\t' && ch != '\0' && ch != '\n' && CParserExpr::m_setOperators.find(ch) == CParserExpr::m_setOperators.end())
	{
		pszCurChar++;

		if (ch == '\\') //运算符的转义符
		{
		    ch = *pszCurChar;
			if (CParserExpr::m_setOperators.find(ch) != CParserExpr::m_setOperators.end()) //是需要转义的特殊字符
			{
				pszCurChar++;
				ch = *pszCurChar;
			}
		}
		else
		{
			ch = *pszCurChar;
		}
	}

	if(m_pszExp != pszCurChar)
	{
		strToken.append(m_pszExp, pszCurChar - m_pszExp);
		m_pszExp = pszCurChar;
	}
	
	//将其中的转义符去掉
	for (pos = 0; (pos = strToken.find('\\', pos)) != string::npos; )
	{
		ch = strToken[pos + 1];
		if (CParserExpr::m_setOperators.find(ch) != CParserExpr::m_setOperators.end())
		{
			strToken.replace(pos, 1, "");
		}
		else  //并不是作为转义符出现
		{
			pos++;
		}
	}
	
	return strToken.data();
}

int CParserExpr::UpdataOperandCount()
{
	tagOperator stOperator;
	if (!m_Operators.empty())
	{
		stOperator = m_Operators.top();
		if (stOperator.nType == 2) //operator is function
		{
			m_Operators.pop();
			stOperator.nOperandsCount++;
			m_Operators.push(stOperator);
			//PushOperator(stOperator);
			return 0;
		}
	}

	return 0;
}

int CParserExpr::GetVarValue(string strValName, tagOperand *pstOperand)
{
	//编码实现	
	return 1;
}

void CParserExpr::GetVarIntoMap(const char *strName, const char *strValue, int nType)
{
	//编码实现	
}

void CParserExpr::ClearVarMap()
{
	m_Map.clear();
}

void CParserExpr::Init()
{
	CParserExpr::m_setOperators.clear();

	CParserExpr::m_setOperators.insert('+');
	CParserExpr::m_setOperators.insert('-');
	CParserExpr::m_setOperators.insert('*');
	CParserExpr::m_setOperators.insert('/');
	CParserExpr::m_setOperators.insert('%');
	CParserExpr::m_setOperators.insert('>');
	CParserExpr::m_setOperators.insert('<');
	CParserExpr::m_setOperators.insert('=');
	CParserExpr::m_setOperators.insert('!');
	CParserExpr::m_setOperators.insert('&');
	CParserExpr::m_setOperators.insert('|');
	CParserExpr::m_setOperators.insert('(');
	CParserExpr::m_setOperators.insert(')');
	CParserExpr::m_setOperators.insert(',');
	CParserExpr::m_setOperators.insert(' ');

}

