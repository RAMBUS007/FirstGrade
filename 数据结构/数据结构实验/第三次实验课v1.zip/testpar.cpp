#include <stdio.h>
#include "ParserExpr.h"

#define scp_exp "(@a+@b) - @c * @d / @b + strcmp(@x, @y)"

int main(int argc, char *argv[])
{
	string exp = scp_exp;
	string a = "10";
	string b = "1";
	string c = "14";
	string d = "3";
	string x = "safdas";
	string y = "3tb";

	CParserExpr::Init();
	CParserExpr pars;
	
	pars.GetVarIntoMap("a", a.c_str(), DATATYPE_INT);
	pars.GetVarIntoMap("b", b.c_str(), DATATYPE_INT);
	pars.GetVarIntoMap("c", c.c_str(), DATATYPE_INT);
	pars.GetVarIntoMap("d", d.c_str(), DATATYPE_INT);
	pars.GetVarIntoMap("x", x.c_str(), DATATYPE_STRING);
	pars.GetVarIntoMap("y", y.c_str(), DATATYPE_STRING);

	int rst;
	char strResult[256];

	memset(strResult, 0, sizeof(strResult));

	rst = pars.ParseExpr(exp, strResult);
	if (rst >= 0)
	{
		printf("%s: %s\n", exp.c_str(), strResult);
	}
	else
	{
		printf("ParseExpr %s failed\n");
	}

	exit(0);

}